package br.unipar.trabalhoapi.model;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class Jogo {

    private Integer id;
    private String titulo;
    private String genero;
    private BigDecimal preco;

}