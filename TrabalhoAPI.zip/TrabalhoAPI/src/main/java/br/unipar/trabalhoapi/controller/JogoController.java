package br.unipar.trabalhoapi.controller;

import br.unipar.trabalhoapi.model.Jogo;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/jogo")
public class JogoController {

    private final List<Jogo> bancoDados = new ArrayList<>();
    private Long proximoId = 1L;

    @GetMapping
    public ResponseEntity<List<Jogo>> listarTodos(@RequestParam(required = false) String titulo,
                                                  @RequestParam(required = false) String genero,
                                                  @RequestParam(required = false) BigDecimal precoMaximo) {

        List<Jogo> resultado = new ArrayList<>();

        for (Jogo j : bancoDados) {
            if (titulo != null && (j.getTitulo() == null || !j.getTitulo().toLowerCase().contains(titulo.toLowerCase()))) {
                continue;
            }
            if (genero != null && (j.getGenero() == null || !j.getGenero().equalsIgnoreCase(genero))) {
                continue;
            }
            if (precoMaximo != null && (j.getPreco() == null || j.getPreco().compareTo(precoMaximo) > 0)) {
                continue;
            }

            resultado.add(j);
        }

        return ResponseEntity.ok(resultado);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Jogo> buscarPorId(@PathVariable Long id) {
        Jogo jogo = encontrarPorId(id);
        if (jogo == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(jogo);
    }

    @PostMapping
    public ResponseEntity<Jogo> cadastrar(@RequestBody Jogo jogo) {
        jogo.setId(proximoId++);
        bancoDados.add(jogo);
        return ResponseEntity.status(HttpStatus.CREATED).body(jogo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Jogo> atualizar(@PathVariable Long id, @RequestBody Jogo dados) {
        Jogo jogo = encontrarPorId(id);
        if (jogo == null) {
            return ResponseEntity.notFound().build();
        }
        jogo.setTitulo(dados.getTitulo());
        jogo.setGenero(dados.getGenero());
        jogo.setPreco(dados.getPreco());
        return ResponseEntity.ok(jogo);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        Jogo jogo = encontrarPorId(id);
        if (jogo == null) {
            return ResponseEntity.notFound().build();
        }
        bancoDados.remove(jogo);
        return ResponseEntity.noContent().build();
    }

    private Jogo encontrarPorId(Long id) {
        for (Jogo j : bancoDados) {
            if (j.getId() != null && j.getId().equals(id)) {
                return j;
            }
        }
        return null;
    }
}