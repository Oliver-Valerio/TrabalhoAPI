package br.unipar.trabalhoapi.controller;

import br.unipar.trabalhoapi.model.Jogo;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/jogo")
public class JogoController {

    // Simulação do banco de dados em memória
    private List<Jogo> bancoDados = new ArrayList<>();

    // GET: Listar todos com suporte a filtros via @RequestParam
    @GetMapping("/listar-todos")
    public ResponseEntity<List<Jogo>> listarTodos(@RequestParam(required = false) String titulo,
                                                  @RequestParam(required = false) String genero,
                                                  @RequestParam(required = false) BigDecimal precoMaximo) {

        if (titulo == null && genero == null && precoMaximo == null) {
            return ResponseEntity.ok(bancoDados);
        }

        List<Jogo> resultado = new ArrayList<>();

        for (Jogo j : bancoDados) {
            boolean atendeFiltro = true;

            if (titulo != null && (j.getTitulo() == null || !j.getTitulo().toLowerCase().contains(titulo.toLowerCase()))) {
                atendeFiltro = false;
            }
            if (genero != null && (j.getGenero() == null || !j.getGenero().equalsIgnoreCase(genero))) {
                atendeFiltro = false;
            }
            if (precoMaximo != null && (j.getPreco() == null || j.getPreco().compareTo(precoMaximo) > 0)) {
                atendeFiltro = false;
            }
            if (atendeFiltro) {
                resultado.add(j);
            }
        }

        return ResponseEntity.ok(resultado);
    }

    // GET: Buscar por posição/índice via @PathVariable
    @GetMapping("/buscar/{index}")
    public ResponseEntity<Jogo> buscarPorId(@PathVariable int index) {
        if (index >= 0 && index < bancoDados.size()) {
            return ResponseEntity.ok(bancoDados.get(index));
        }
        return ResponseEntity.notFound().build();
    }

    // POST: Cadastrar um novo jogo
    @PostMapping("/gravar")
    public String gravarJogo(@RequestBody(required = false) Jogo jogo) {
        if (jogo == null) {
            return "Hello World, Stranger!";
        } else {
            bancoDados.add(jogo);
            return "Jogo cadastrado com sucesso: " + jogo.getTitulo();
        }
    }

    // PUT: Editar jogo existente por índice
    @PutMapping("/editar/{index}")
    public ResponseEntity<Jogo> editarJogo(@PathVariable int index,
                                           @RequestBody(required = false) Jogo jogo) {
        if (jogo == null || index < 0 || index >= bancoDados.size()) {
            return ResponseEntity.noContent().build();
        }

        Jogo j = new Jogo();
        j.setId(jogo.getId());
        j.setTitulo(jogo.getTitulo());
        j.setGenero(jogo.getGenero());
        j.setPreco(jogo.getPreco());

        bancoDados.set(index, j);

        return ResponseEntity.ok(j);
    }

    // DELETE: Apagar jogo por índice
    @DeleteMapping("/deletar/{index}")
    public ResponseEntity<String> deletarJogo(@PathVariable int index) {
        if (index >= 0 && index < bancoDados.size()) {
            bancoDados.remove(index);
            return ResponseEntity.ok("Jogo no índice " + index + " deletado com sucesso!");
        }
        return ResponseEntity.notFound().build();
    }
}